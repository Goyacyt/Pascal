struct Complex{
        float real;
        float image;
}c;
int main(){
        c.image=4;
}
