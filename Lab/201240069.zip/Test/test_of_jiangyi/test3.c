int main(){
        int i=09;
        int j=0x3G;
}
