int main()
{
    float i=1.05e;
}
