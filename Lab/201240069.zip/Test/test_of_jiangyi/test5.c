int main(){
        /*
        comment
        /*
        nested comment
        */
        */
        int i=1;
}
