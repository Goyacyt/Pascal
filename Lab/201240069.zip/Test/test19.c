int main(){
        int i=1;
        int j=2;
        c(i,j)
        i=i+1
        if(i>1){
                i=i+1;
                i=i+5;
        }
        return 0;
}
