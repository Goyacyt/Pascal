int main()
{
        int i=~;
        int j;
}
