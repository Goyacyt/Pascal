int funct(){
        int j=1
        int q=
        if (s==0){
                j=2;
        }
}
