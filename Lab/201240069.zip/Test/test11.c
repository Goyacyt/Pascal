int main(){
        int i=1
        int j=2
        int s=3
        int k=4;
}

