int main( j=3 ){
        int j=0x111
        int l=0X111;
        f=067;
        g=34;
        return 0;
}
