int main(){
        int j=3*-5;
        return 0;
}
