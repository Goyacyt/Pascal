int main(){
        int j=0123;
        int k=0x23;
}
