int main(){
    int j=1.04e-4;
}
