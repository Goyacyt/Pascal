int main(){
    int j=.e4;
}
