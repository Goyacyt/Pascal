int main(){
        int k=1
        j=0;
        while(1){}
        if (1){
                return 0;
        }
        return 0;
}
