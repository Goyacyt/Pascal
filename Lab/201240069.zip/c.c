#include<stdio.h>
int main(){
    int i;
    i=-3*-5/4;
 //   i=5*-8/3;
    printf("%d\n",i);
    return 0;
}